<?php

namespace App\Controller;


use App\Entity\User;
use App\Form\UserType;
use App\Repository\UserRepository;
use  Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class UserController extends AbstractController
{
    #[Route('/user', name: 'app_user')]
    public function index(): Response
    {
        return $this->render('user/index.html.twig', [
            'controller_name' => 'UserController',
        ]);
    }
    
    #[Route('/read', name: 'user_read')]
    public function read(ManagerRegistry $doctrine): Response
    {
        $user = $doctrine->getRepository(User::class)->findAll();
        return $this->render('user/read.html.twig',
            ["user" => $user]);
    }


    #[Route('/add', name: 'user_add')]
    public function  add(ManagerRegistry $doctrine, Request  $request) : Response
    { $user = new User() ;
        $form = $this->createForm(UserType::class, $user);
        $form->add('ajouter', SubmitType::class) ;
        $form->handleRequest($request);
        if ($form->isSubmitted())
        { $em = $doctrine->getManager();
            $em->persist($user);
            $em->flush();
            return $this->redirectToRoute('user_read');
        }
        return $this->renderForm("user/add.html.twig",
            ["f"=>$form]) ;


    }
    #[Route('/update/{id}', name: 'user_update')]
    public function  update(ManagerRegistry $doctrine,$id,  Request  $request) : Response
    { $user = $doctrine
        ->getRepository(User::class)
        ->find($id);
        $form = $this->createForm(UserType::class, $user);
        $form->add('update', SubmitType::class) ;
        $form->handleRequest($request);
        if ($form->isSubmitted())
        { $em = $doctrine->getManager();
            $em->flush();
            return $this->redirectToRoute('user_read');
        }
        return $this->renderForm("user/update.html.twig",
            ["f"=>$form]) ;


    }
    #[Route("/delete/{id}", name:'user_delete')]
    public function delete($id, ManagerRegistry $doctrine)
    {$c = $doctrine
        ->getRepository(User::class)
        ->find($id);
        $em = $doctrine->getManager();
        $em->remove($u);
        $em->flush() ;
        return $this->redirectToRoute('user_read');
    }

}
