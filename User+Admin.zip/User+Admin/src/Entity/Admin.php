<?php

namespace App\Entity;

use App\Repository\AdminRepository;
use Doctrine\ORM\Mapping as ORM;

use App\Form\FileType;

#[ORM\Entity(repositoryClass: AdminRepository::class)]
class Admin
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $emailAdmin = null;

    #[ORM\Column(length: 255)]
    private ?string $nomAdmin = null;

    #[ORM\Column(length: 255)]
    private ?string $prenomAdmin = null;

    #[ORM\Column(length: 255)]
    private ?string $passwordAdmin = null;

    #[ORM\Column]
    private ?int $telAdmin = null;

    #[ORM\Column(length: 255)]
    private ?string $imageAdmin = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEmailAdmin(): ?string
    {
        return $this->emailAdmin;
    }

    public function setEmailAdmin(string $emailAdmin): self
    {
        $this->emailAdmin = $emailAdmin;

        return $this;
    }

    public function getNomAdmin(): ?string
    {
        return $this->nomAdmin;
    }

    public function setNomAdmin(string $nomAdmin): self
    {
        $this->nomAdmin = $nomAdmin;

        return $this;
    }

    public function getPrenomAdmin(): ?string
    {
        return $this->prenomAdmin;
    }

    public function setPrenomAdmin(string $prenomAdmin): self
    {
        $this->prenomAdmin = $prenomAdmin;

        return $this;
    }

    public function getPasswordAdmin(): ?string
    {
        return $this->passwordAdmin;
    }

    public function setPasswordAdmin(string $passwordAdmin): self
    {
        $this->passwordAdmin = $passwordAdmin;

        return $this;
    }

    public function getTelAdmin(): ?int
    {
        return $this->telAdmin;
    }

    public function setTelAdmin(int $telAdmin): self
    {
        $this->telAdmin = $telAdmin;

        return $this;
    }

    public function getImageAdmin(): ?string
    {
        return $this->imageAdmin;
    }

    public function setImageAdmin(string $imageAdmin): self
    {
        $this->imageAdmin = $imageAdmin;

        return $this;
    }
}
