<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* contrat/updatecontrat.html.twig */
class __TwigTemplate_a95d8f876774124cd84efe622e3e733c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contrat/updatecontrat.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contrat/updatecontrat.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "contrat/updatecontrat.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    ";
        // line 5
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["f"]) || array_key_exists("f", $context) ? $context["f"] : (function () { throw new RuntimeError('Variable "f" does not exist.', 5, $this->source); })()), 'form_start', ["attr" => ["novalidate" => "novalidate"]]);
        echo "
    <!-- tap on top start -->

    <div class=\"page-body\">

        <!-- New Product Add Start -->
        <form method=\"post\">
            <div class=\"container-fluid\">
                <div class=\"row\">
                    <div class=\"col-12\">
                        <div class=\"row\">
                            <div class=\"col-sm-8 m-auto\">
                                <div class=\"card\">
                                    <div class=\"card-body\">
                                        <div class=\"card-header-2\">
                                            <h5>Contrat Update</h5>
                                        </div>

                                        <form class=\"theme-form theme-form-2 mega-form\">
                                            <div class=\"mb-4 row align-items-center\">
                                                ";
        // line 25
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["f"]) || array_key_exists("f", $context) ? $context["f"] : (function () { throw new RuntimeError('Variable "f" does not exist.', 25, $this->source); })()), "datesignature", [], "any", false, false, false, 25), 'row');
        echo "
                                            </div>

                                            <div class=\"mb-4 row align-items-center\">
                                                ";
        // line 29
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["f"]) || array_key_exists("f", $context) ? $context["f"] : (function () { throw new RuntimeError('Variable "f" does not exist.', 29, $this->source); })()), "dateexpiration", [], "any", false, false, false, 29), 'row');
        echo "
                                            </div>

                                            <div class=\"mb-4 row align-items-center\">
                                                ";
        // line 33
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["f"]) || array_key_exists("f", $context) ? $context["f"] : (function () { throw new RuntimeError('Variable "f" does not exist.', 33, $this->source); })()), "idfournisseur", [], "any", false, false, false, 33), 'row');
        echo "
                                            </div>

                                            <div class=\"mb-4 row align-items-center\">

                                                ";
        // line 38
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["f"]) || array_key_exists("f", $context) ? $context["f"] : (function () { throw new RuntimeError('Variable "f" does not exist.', 38, $this->source); })()), "produitfournit", [], "any", false, false, false, 38), 'row');
        echo "
                                            </div>





                                    </div>
                                    <input type=\"submit\" value=\"Update\"/>
                                </div>
        </form>
    </div>
    </div>

    ";
        // line 52
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["f"]) || array_key_exists("f", $context) ? $context["f"] : (function () { throw new RuntimeError('Variable "f" does not exist.', 52, $this->source); })()), 'form_end');
        echo "
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    public function getTemplateName()
    {
        return "contrat/updatecontrat.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  133 => 52,  116 => 38,  108 => 33,  101 => 29,  94 => 25,  71 => 5,  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}

    {{form_start(f,{'attr': {'novalidate': 'novalidate'}} )}}
    <!-- tap on top start -->

    <div class=\"page-body\">

        <!-- New Product Add Start -->
        <form method=\"post\">
            <div class=\"container-fluid\">
                <div class=\"row\">
                    <div class=\"col-12\">
                        <div class=\"row\">
                            <div class=\"col-sm-8 m-auto\">
                                <div class=\"card\">
                                    <div class=\"card-body\">
                                        <div class=\"card-header-2\">
                                            <h5>Contrat Update</h5>
                                        </div>

                                        <form class=\"theme-form theme-form-2 mega-form\">
                                            <div class=\"mb-4 row align-items-center\">
                                                {{ form_row(f.datesignature) }}
                                            </div>

                                            <div class=\"mb-4 row align-items-center\">
                                                {{ form_row(f.dateexpiration) }}
                                            </div>

                                            <div class=\"mb-4 row align-items-center\">
                                                {{ form_row(f.idfournisseur) }}
                                            </div>

                                            <div class=\"mb-4 row align-items-center\">

                                                {{ form_row(f.produitfournit) }}
                                            </div>





                                    </div>
                                    <input type=\"submit\" value=\"Update\"/>
                                </div>
        </form>
    </div>
    </div>

    {{ form_end(f) }}
{% endblock %}
", "contrat/updatecontrat.html.twig", "C:\\xampp\\htdocs\\Contrat\\templates\\contrat\\updatecontrat.html.twig");
    }
}
