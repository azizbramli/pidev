<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* contrat/readcontrat.html.twig */
class __TwigTemplate_2aea4e1de8140d1a6d2d9f51efef5d48 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
            'stylesheets' => [$this, 'block_stylesheets'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contrat/readcontrat.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contrat/readcontrat.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "contrat/readcontrat.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 7
        echo "    ";
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 48
        echo "


<div class=\"page-body\">
    <div class=\"container-fluid\">
        <div class=\"row\">
            <div class=\"col-sm-12\">
                <div class=\"card card-table\">
                    <div class=\"card-body\">
                        <div class=\"title-header option-title d-sm-flex d-block\">
                            <h5>Contrat List</h5>

                        </div>
                        <div>
                            <div class=\"table-responsive\">
                                <table class=\"table all-package theme-table table-product\" id=\"table_id\">
                                    <thead>
                                    <tr>


                                        <th>Id</th>
                                        <th> date signature</th>
                                        <th> date expiration</th>
                                        <th> id fournisseur </th>
                                        <th> produit fournit</th>
                                        <th> image </th>
                                    </tr>
                                    </thead>


                                    <div class=\"example-wrapper\">



                                        ";
        // line 82
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["contrat"]) || array_key_exists("contrat", $context) ? $context["contrat"] : (function () { throw new RuntimeError('Variable "contrat" does not exist.', 82, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["c"]) {
            // line 83
            echo "                                        <tr>
                                            <td>  ";
            // line 84
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["c"], "id", [], "any", false, false, false, 84), "html", null, true);
            echo "</td>
                                            <td>   ";
            // line 85
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["c"], "datesignature", [], "any", false, false, false, 85), "d/m/Y"), "html", null, true);
            echo " </td>
                                            <td>   ";
            // line 86
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["c"], "dateexpiration", [], "any", false, false, false, 86), "d/m/Y"), "html", null, true);
            echo " </td>
                                            <td>   ";
            // line 87
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["c"], "idfournisseur", [], "any", false, false, false, 87), "html", null, true);
            echo " </td>
                                            <td>   ";
            // line 88
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["c"], "produitfournit", [], "any", false, false, false, 88), "html", null, true);
            echo " </td>
                                            <td>

                                            </td>
                                            <td> <a href=\"";
            // line 92
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("contrat_delete", ["id" => twig_get_attribute($this->env, $this->source, $context["c"], "id", [], "any", false, false, false, 92)]), "html", null, true);
            echo "\">Delete </a>
                                                <a href=\"";
            // line 93
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("contrat_update", ["id" => twig_get_attribute($this->env, $this->source, $context["c"], "id", [], "any", false, false, false, 93)]), "html", null, true);
            echo "\">Update </a>

                                            </td>
                                        </tr>
                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['c'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 98
        echo "                                </table>
    <form action=\"";
        // line 99
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("contrat_add");
        echo "\">
        <button class=\"btn  btn--yes btn-primary\">Add contrat</button>

    </form>





";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 4
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 5
        echo "        <script language = \"javascript\" src = \"https://code.jquery.com/jquery-2.2.4.min.js\"></script>
    ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "        <style>
            #simpleform {
                width:600px;
                border:2px solid grey;
                padding:14px;
            }
            #simpleform label {
                font-size:12px;
                float:left;
                width:300px;
                text-align:right;
                display:block;
            }
            #simpleform span {
                font-size:11px;
                color:grey;
                width:100px;
                text-align:right;
                display:block;
            }
            #simpleform input {
                border:1px solid grey;
                font-family:verdana;
                font-size:14px;
                color:grey;
                height:24px;
                width:250px;
                margin: 0 0 20px 10px;
            }
            #simpleform button {
                clear:both;
                margin-left:250px;
                background:grey;
                color:#FFFFFF;
                border:solid 1px #666666;
                font-size:16px;
            }
        </style>

    ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    public function getTemplateName()
    {
        return "contrat/readcontrat.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  211 => 8,  201 => 7,  190 => 5,  180 => 4,  160 => 99,  157 => 98,  146 => 93,  142 => 92,  135 => 88,  131 => 87,  127 => 86,  123 => 85,  119 => 84,  116 => 83,  112 => 82,  76 => 48,  73 => 7,  70 => 4,  60 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}
    {% block javascripts %}
        <script language = \"javascript\" src = \"https://code.jquery.com/jquery-2.2.4.min.js\"></script>
    {% endblock %}
    {% block stylesheets %}
        <style>
            #simpleform {
                width:600px;
                border:2px solid grey;
                padding:14px;
            }
            #simpleform label {
                font-size:12px;
                float:left;
                width:300px;
                text-align:right;
                display:block;
            }
            #simpleform span {
                font-size:11px;
                color:grey;
                width:100px;
                text-align:right;
                display:block;
            }
            #simpleform input {
                border:1px solid grey;
                font-family:verdana;
                font-size:14px;
                color:grey;
                height:24px;
                width:250px;
                margin: 0 0 20px 10px;
            }
            #simpleform button {
                clear:both;
                margin-left:250px;
                background:grey;
                color:#FFFFFF;
                border:solid 1px #666666;
                font-size:16px;
            }
        </style>

    {% endblock %}



<div class=\"page-body\">
    <div class=\"container-fluid\">
        <div class=\"row\">
            <div class=\"col-sm-12\">
                <div class=\"card card-table\">
                    <div class=\"card-body\">
                        <div class=\"title-header option-title d-sm-flex d-block\">
                            <h5>Contrat List</h5>

                        </div>
                        <div>
                            <div class=\"table-responsive\">
                                <table class=\"table all-package theme-table table-product\" id=\"table_id\">
                                    <thead>
                                    <tr>


                                        <th>Id</th>
                                        <th> date signature</th>
                                        <th> date expiration</th>
                                        <th> id fournisseur </th>
                                        <th> produit fournit</th>
                                        <th> image </th>
                                    </tr>
                                    </thead>


                                    <div class=\"example-wrapper\">



                                        {%  for c in  contrat %}
                                        <tr>
                                            <td>  {{ c.id }}</td>
                                            <td>   {{ c.datesignature|date(\"d/m/Y\") }} </td>
                                            <td>   {{ c.dateexpiration|date(\"d/m/Y\")}} </td>
                                            <td>   {{ c.idfournisseur }} </td>
                                            <td>   {{ c.produitfournit }} </td>
                                            <td>

                                            </td>
                                            <td> <a href=\"{{ path('contrat_delete', {id:c.id}) }}\">Delete </a>
                                                <a href=\"{{ path('contrat_update', {id:c.id}) }}\">Update </a>

                                            </td>
                                        </tr>
                                        {% endfor %}
                                </table>
    <form action=\"{{ path('contrat_add') }}\">
        <button class=\"btn  btn--yes btn-primary\">Add contrat</button>

    </form>





{% endblock %}", "contrat/readcontrat.html.twig", "C:\\xampp\\htdocs\\Contrat\\templates\\contrat\\readcontrat.html.twig");
    }
}
