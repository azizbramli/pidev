<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_d37d1c3621cb1b31c9f974580366ac09 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'css' => [$this, 'block_css'],
            'body' => [$this, 'block_body'],
            'js' => [$this, 'block_js'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\" dir=\"ltr\">


<!-- Mirrored from themes.pixelstrap.com/fastkart/back-end/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 10 Feb 2023 23:32:15 GMT -->
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta name=\"description\"
          content=\"Fastkart admin is super flexible, powerful, clean &amp; modern responsive bootstrap 5 admin template with unlimited possibilities.\">
    <meta name=\"keywords\"
          content=\"admin template, Fastkart admin template, dashboard template, flat admin template, responsive admin template, web app\">
    <meta name=\"author\" content=\"pixelstrap\">
    <link rel=\"icon\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/favicon.png"), "html", null, true);
        echo "\" type=\"image/x-icon\">
    <link rel=\"shortcut icon\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/favicon.png"), "html", null, true);
        echo "\" type=\"image/x-icon\">

    <title>";
        // line 18
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    <!-- Google font-->
    <link
            href=\"https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap\"
            rel=\"stylesheet\">

    <!-- Linear Icon css -->

    ";
        // line 27
        $this->displayBlock('css', $context, $blocks);
        // line 62
        echo "</head>

<body>

<!-- tap on top start -->
<div class=\"tap-top\">
    <span class=\"lnr lnr-chevron-up\"></span>
</div>
<!-- tap on tap end -->

<!-- page-wrapper Start-->
<div class=\"page-wrapper compact-wrapper\" id=\"pageWrapper\">
    <!-- Page Header Start-->
    <div class=\"page-header\">
        <div class=\"header-wrapper m-0\">
            <div class=\"header-logo-wrapper p-0\">
                <div class=\"logo-wrapper\">
                    <a href=\"index.html\">
                        <img class=\"img-fluid main-logo\" src=\"";
        // line 80
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/logo/1.png"), "html", null, true);
        echo "\" alt=\"logo\">
                        <img class=\"img-fluid white-logo\" src=\"";
        // line 81
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/logo/1-white.png"), "html", null, true);
        echo "\" alt=\"logo\">
                    </a>
                </div>
                <div class=\"toggle-sidebar\">
                    <i class=\"status_toggle middle sidebar-toggle\" data-feather=\"align-center\"></i>
                    <a href=\"index.html\">
                        <img src=\"";
        // line 87
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/logo/1.png"), "html", null, true);
        echo "\" class=\"img-fluid\" alt=\"\">
                    </a>
                </div>
            </div>

            <form class=\"form-inline search-full\" action=\"javascript:void(0)\" method=\"get\">
                <div class=\"form-group w-100\">
                    <div class=\"Typeahead Typeahead--twitterUsers\">
                        <div class=\"u-posRelative\">
                            <input class=\"demo-input Typeahead-input form-control-plaintext w-100\" type=\"text\"
                                   placeholder=\"Search Fastkart ..\" name=\"q\" title=\"\" autofocus>
                            <i class=\"close-search\" data-feather=\"x\"></i>
                            <div class=\"spinner-border Typeahead-spinner\" role=\"status\">
                                <span class=\"sr-only\">Loading...</span>
                            </div>
                        </div>
                        <div class=\"Typeahead-menu\"></div>
                    </div>
                </div>
            </form>
            <div class=\"nav-right col-6 pull-right right-header p-0\">
                <ul class=\"nav-menus\">
                    <li>
                            <span class=\"header-search\">
                                <i class=\"ri-search-line\"></i>
                            </span>
                    </li>
                    <li class=\"onhover-dropdown\">
                        <div class=\"notification-box\">
                            <i class=\"ri-notification-line\"></i>
                            <span class=\"badge rounded-pill badge-theme\">4</span>
                        </div>
                        <ul class=\"notification-dropdown onhover-show-div\">
                            <li>
                                <i class=\"ri-notification-line\"></i>
                                <h6 class=\"f-18 mb-0\">Notitications</h6>
                            </li>
                            <li>
                                <p>
                                    <i class=\"fa fa-circle me-2 font-primary\"></i>Delivery processing <span
                                            class=\"pull-right\">10 min.</span>
                                </p>
                            </li>
                            <li>
                                <p>
                                    <i class=\"fa fa-circle me-2 font-success\"></i>Order Complete<span
                                            class=\"pull-right\">1 hr</span>
                                </p>
                            </li>
                            <li>
                                <p>
                                    <i class=\"fa fa-circle me-2 font-info\"></i>Tickets Generated<span
                                            class=\"pull-right\">3 hr</span>
                                </p>
                            </li>
                            <li>
                                <p>
                                    <i class=\"fa fa-circle me-2 font-danger\"></i>Delivery Complete<span
                                            class=\"pull-right\">6 hr</span>
                                </p>
                            </li>
                            <li>
                                <a class=\"btn btn-primary\" href=\"";
        // line 149
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("javascript:void(0)"), "html", null, true);
        echo "\">Check all notification</a>
                            </li>
                        </ul>
                    </li>

                    <li>
                        <div class=\"mode\">
                            <i class=\"ri-moon-line\"></i>
                        </div>
                    </li>
                    <li class=\"profile-nav onhover-dropdown pe-0 me-0\">
                        <div class=\"media profile-media\">
                            <img class=\"user-profile rounded-circle\" src=\"";
        // line 161
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/users/4.jpg"), "html", null, true);
        echo "\" alt=\"\">
                            <div class=\"user-name-hide media-body\">
                                <span>Emay Walter</span>
                                <p class=\"mb-0 font-roboto\">Admin<i class=\"middle ri-arrow-down-s-line\"></i></p>
                            </div>
                        </div>
                        <ul class=\"profile-dropdown onhover-show-div\">
                            <li>
                                <a href=\"all-users.html\">
                                    <i data-feather=\"users\"></i>
                                    <span>Users</span>
                                </a>
                            </li>
                            <li>
                                <a href=\"order-list.html\">
                                    <i data-feather=\"archive\"></i>
                                    <span>Orders</span>
                                </a>
                            </li>
                            <li>
                                <a href=\"support-ticket.html\">
                                    <i data-feather=\"phone\"></i>
                                    <span>Spports Tickets</span>
                                </a>
                            </li>
                            <li>
                                <a href=\"profile-setting.html\">
                                    <i data-feather=\"settings\"></i>
                                    <span>Settings</span>
                                </a>
                            </li>
                            <li>
                                <a data-bs-toggle=\"modal\" data-bs-target=\"#staticBackdrop\"
                                   href=\"javascript:void(0)\">
                                    <i data-feather=\"log-out\"></i>
                                    <span>Log out</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Page Header Ends-->

    <!-- Page Body Start-->
    <div class=\"page-body-wrapper\">
        <!-- Page Sidebar Start-->
        <div class=\"sidebar-wrapper\">
            <div id=\"sidebarEffect\"></div>
            <div>
                <div class=\"logo-wrapper logo-wrapper-center\">
                    <a href=\"index.html\" data-bs-original-title=\"\" title=\"\">
                        <img class=\"img-fluid for-white\" src=\"";
        // line 215
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/logo/1.png"), "html", null, true);
        echo "\" alt=\"logo\">

                    </a>
                    <div class=\"back-btn\">
                        <i class=\"fa fa-angle-left\"></i>
                    </div>
                    <div class=\"toggle-sidebar\">
                        <i class=\"ri-apps-line status_toggle middle sidebar-toggle\"></i>
                    </div>
                </div>
                <div class=\"logo-icon-wrapper\">
                    <a href=\"index.html\">
                        <img class=\"img-fluid main-logo main-white\" src=\"";
        // line 227
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/logo/logo.png"), "html", null, true);
        echo "\" alt=\"logo\">
                        <img class=\"img-fluid main-logo main-dark\" src=\"";
        // line 228
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/logo/logo-white.png"), "html", null, true);
        echo "\"
                             alt=\"logo\">
                    </a>
                </div>
                <nav class=\"sidebar-main\">
                    <div class=\"left-arrow\" id=\"left-arrow\">
                        <i data-feather=\"arrow-left\"></i>
                    </div>

                    <div id=\"sidebar-menu\">
                        <ul class=\"sidebar-links\" id=\"simple-bar\">
                            <li class=\"back-btn\"></li>
                            <br>
                            <br>

                            <li class=\"sidebar-list\">
                                <a class=\"sidebar-link sidebar-title link-nav\" href=\"index.html\">
                                    <i class=\"ri-home-line\"></i>
                                    <span>Dashboard</span>
                                </a>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"linear-icon-link sidebar-link sidebar-title\" href=\"javascript:void(0)\">
                                    <i class=\"ri-store-3-line\"></i>
                                    <span>Contrat</span>
                                </a>
                                <ul class=\"sidebar-submenu\">
                                    <li>
                                        <a href=\"";
        // line 257
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("contrat_read");
        echo "\">Contrat</a>
                                    </li>

                                    <li>
                                        <a href=\"";
        // line 261
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("contrat_add");
        echo "\">Add New Contrat</a>
                                    </li>
                                </ul>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"linear-icon-link sidebar-link sidebar-title\" href=\"javascript:void(0)\">
                                    <i class=\"ri-list-check-2\"></i>
                                    <span>Category</span>
                                </a>
                                <ul class=\"sidebar-submenu\">
                                    <li>
                                        <a href=\"category.html\">Category List</a>
                                    </li>

                                    <li>
                                        <a href=\"add-new-category.html\">Add New Category</a>
                                    </li>
                                </ul>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"linear-icon-link sidebar-link sidebar-title\" href=\"";
        // line 283
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("javascript:void(0)"), "html", null, true);
        echo "\">
                                    <i class=\"ri-list-settings-line\"></i>
                                    <span>Attributes</span>
                                </a>
                                <ul class=\"sidebar-submenu\">
                                    <li>
                                        <a href=\"attributes.html\">Attributes</a>
                                    </li>

                                    <li>
                                        <a href=\"add-new-attributes.html\">Add Attributes</a>
                                    </li>
                                </ul>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"sidebar-link sidebar-title\" href=\"";
        // line 299
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("javascript:void(0)"), "html", null, true);
        echo "\">
                                    <i class=\"ri-user-3-line\"></i>
                                    <span>Users</span>
                                </a>
                                <ul class=\"sidebar-submenu\">
                                    <li>
                                        <a href=\"all-users.html\">All users</a>
                                    </li>
                                    <li>
                                        <a href=\"add-new-user.html\">Add new user</a>
                                    </li>
                                </ul>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"sidebar-link sidebar-title\" href=\"";
        // line 314
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("javascript:void(0)"), "html", null, true);
        echo "\">
                                    <i class=\"ri-user-3-line\"></i>
                                    <span>Roles</span>
                                </a>
                                <ul class=\"sidebar-submenu\">
                                    <li>
                                        <a href=\"role.html\">All roles</a>
                                    </li>
                                    <li>
                                        <a href=\"create-role.html\">Create Role</a>
                                    </li>
                                </ul>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"sidebar-link sidebar-title link-nav\" href=\"media.html\">
                                    <i class=\"ri-price-tag-3-line\"></i>
                                    <span>Media</span>
                                </a>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"sidebar-link sidebar-title\" href=\"";
        // line 336
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("javascript:void(0)"), "html", null, true);
        echo "\">
                                    <i class=\"ri-archive-line\"></i>
                                    <span>Orders</span>
                                </a>
                                <ul class=\"sidebar-submenu\">
                                    <li>
                                        <a href=\"order-list.html\">Order List</a>
                                    </li>
                                    <li>
                                        <a href=\"order-detail.html\">Order Detail</a>
                                    </li>
                                    <li>
                                        <a href=\"order-tracking.html\">Order Tracking</a>
                                    </li>
                                </ul>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"linear-icon-link sidebar-link sidebar-title\" href=\"";
        // line 354
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("javascript:void(0)"), "html", null, true);
        echo "\">
                                    <i class=\"ri-focus-3-line\"></i>
                                    <span>Localization</span>
                                </a>
                                <ul class=\"sidebar-submenu\">
                                    <li>
                                        <a href=\"translation.html\">Translation</a>
                                    </li>

                                    <li>
                                        <a href=\"currency-rates.html\">Currency Rates</a>
                                    </li>
                                </ul>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"linear-icon-link sidebar-link sidebar-title\" href=\"";
        // line 370
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("javascript:void(0)"), "html", null, true);
        echo "\">
                                    <i class=\"ri-price-tag-3-line\"></i>
                                    <span>Coupons</span>
                                </a>
                                <ul class=\"sidebar-submenu\">
                                    <li>
                                        <a href=\"coupon-list.html\">Coupon List</a>
                                    </li>

                                    <li>
                                        <a href=\"create-coupon.html\">Create Coupon</a>
                                    </li>
                                </ul>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"sidebar-link sidebar-title link-nav\" href=\"taxes.html\">
                                    <i class=\"ri-price-tag-3-line\"></i>
                                    <span>Tax</span>
                                </a>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"sidebar-link sidebar-title link-nav\" href=\"product-review.html\">
                                    <i class=\"ri-star-line\"></i>
                                    <span>Product Review</span>
                                </a>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"sidebar-link sidebar-title link-nav\" href=\"support-ticket.html\">
                                    <i class=\"ri-phone-line\"></i>
                                    <span>Support Ticket</span>
                                </a>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"linear-icon-link sidebar-link sidebar-title\" href=\"";
        // line 407
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("javascript:void(0)"), "html", null, true);
        echo "\">
                                    <i class=\"ri-settings-line\"></i>
                                    <span>Settings</span>
                                </a>
                                <ul class=\"sidebar-submenu\">
                                    <li>
                                        <a href=\"profile-setting.html\">Profile Setting</a>
                                    </li>
                                </ul>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"sidebar-link sidebar-title link-nav\" href=\"reports.html\">
                                    <i class=\"ri-file-chart-line\"></i>
                                    <span>Reports</span>
                                </a>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"sidebar-link sidebar-title link-nav\" href=\"list-page.html\">
                                    <i class=\"ri-list-check\"></i>
                                    <span>List Page</span>
                                </a>
                            </li>
                        </ul>
                    </div>

                    <div class=\"right-arrow\" id=\"right-arrow\">
                        <i data-feather=\"arrow-right\"></i>
                    </div>
                </nav>
            </div>
        </div>
        <!-- Page Sidebar Ends-->
        <div class=\"container mt-3\">
        ";
        // line 442
        $this->displayBlock('body', $context, $blocks);
        // line 445
        echo "        </div>

        <!-- footer start-->
        <div class=\"container-fluid\">
            <footer class=\"footer\">
                <div class=\"row\">
                    <div class=\"col-md-12 footer-copyright text-center\">
                        <p class=\"mb-0\">Copyright 2022 © Fastkart theme by cody</p>
                    </div>
                </div>
            </footer>
        </div>
        <!-- footer End-->
    </div>
    <!-- index body end -->

</div>
<!-- Page Body End -->
</div>
<!-- page-wrapper End-->

<!-- Modal Start -->
<div class=\"modal fade\" id=\"staticBackdrop\" data-bs-backdrop=\"static\" data-bs-keyboard=\"false\" tabindex=\"-1\"
     aria-labelledby=\"staticBackdropLabel\" aria-hidden=\"true\">
    <div class=\"modal-dialog  modal-dialog-centered\">
        <div class=\"modal-content\">
            <div class=\"modal-body\">
                <h5 class=\"modal-title\" id=\"staticBackdropLabel\">Logging Out</h5>
                <p>Are you sure you want to log out?</p>
                <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"modal\" aria-label=\"Close\"></button>
                <div class=\"button-box\">
                    <button type=\"button\" class=\"btn btn--no\" data-bs-dismiss=\"modal\">No</button>
                    <button type=\"button\" class=\"btn  btn--yes btn-primary\">Yes</button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal End -->

<!-- latest js -->
";
        // line 486
        $this->displayBlock('js', $context, $blocks);
        // line 537
        echo "</body>


<!-- Mirrored from themes.pixelstrap.com/fastkart/back-end/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 10 Feb 2023 23:32:41 GMT -->
</html>";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 18
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo " Dashbord ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 27
    public function block_css($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "css"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "css"));

        // line 28
        echo "
        <link rel=\"stylesheet\" href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/linearicon.css"), "html", null, true);
        echo "\">

        <!-- fontawesome css -->
        <link rel=\"stylesheet\" href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/vendors/font-awesome.css"), "html", null, true);
        echo "\">

        <!-- Themify icon css-->
        <link rel=\"stylesheet\" href=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/vendors/themify.css"), "html", null, true);
        echo "\">

        <!-- ratio css -->
        <link rel=\"stylesheet\" href=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/ratio.css"), "html", null, true);
        echo "\">

        <!-- remixicon css -->
        <link rel=\"stylesheet\" href=\"";
        // line 41
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/remixicon.css"), "html", null, true);
        echo "\">

        <!-- Feather icon css-->
        <link rel=\"stylesheet\" href=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/vendors/feather-icon.css"), "html", null, true);
        echo "\">

        <!-- Plugins css -->
        <link rel=\"stylesheet\" href=\"";
        // line 47
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/vendors/scrollbar.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 48
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/vendors/animate.css"), "html", null, true);
        echo "\">

        <!-- Bootstrap css-->
        <link rel=\"stylesheet\" href=\"";
        // line 51
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/vendors/bootstrap.css"), "html", null, true);
        echo "\">

        <!-- vector map css -->
        <link rel=\"stylesheet\" href=\"";
        // line 54
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/vector-map.css"), "html", null, true);
        echo "\">

        <!-- Slick Slider Css -->
        <link rel=\"stylesheet\" href=\"";
        // line 57
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/vendors/slick.css"), "html", null, true);
        echo "\">

        <!-- App css -->
        <link rel=\"stylesheet\" href=\"";
        // line 60
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 442
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 443
        echo "
        ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 486
    public function block_js($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        // line 487
        echo "    <!-- latest js -->
    <script src=\"";
        // line 488
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/jquery-3.6.0.min.js"), "html", null, true);
        echo "\"></script>

    <!-- Bootstrap js -->
    <script src=\"";
        // line 491
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/bootstrap/bootstrap.bundle.min.js"), "html", null, true);
        echo "\"></script>

    <!-- feather icon js -->
    <script src=\"";
        // line 494
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/icons/feather-icon/feather.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 495
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/icons/feather-icon/feather-icon.js"), "html", null, true);
        echo "\"></script>

    <!-- scrollbar simplebar js -->
    <script src=\"";
        // line 498
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/scrollbar/simplebar.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 499
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/scrollbar/custom.js"), "html", null, true);
        echo "\"></script>

    <!-- Sidebar jquery -->
    <script src=\"";
        // line 502
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/config.js"), "html", null, true);
        echo "\"></script>

    <!-- tooltip init js -->
    <script src=\"";
        // line 505
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/tooltip-init.js"), "html", null, true);
        echo "\"></script>

    <!-- Plugins JS -->
    <script src=\"";
        // line 508
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/sidebar-menu.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 509
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/notify/bootstrap-notify.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 510
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/notify/index.js"), "html", null, true);
        echo "\"></script>

    <!-- Apexchar js -->
    <script src=\"";
        // line 513
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/chart/apex-chart/apex-chart1.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 514
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/chart/apex-chart/moment.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 515
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/chart/apex-chart/apex-chart.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 516
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/chart/apex-chart/stock-prices.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 517
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/chart/apex-chart/chart-custom1.js"), "html", null, true);
        echo "\"></script>


    <!-- slick slider js -->
    <script src=\"";
        // line 521
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/slick.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 522
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/custom-slick.js"), "html", null, true);
        echo "\"></script>

    <!-- customizer js -->
    <script src=\"";
        // line 525
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/customizer.js"), "html", null, true);
        echo "\"></script>

    <!-- ratio js -->
    <script src=\"";
        // line 528
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/ratio.js"), "html", null, true);
        echo "\"></script>

    <!-- sidebar effect -->
    <script src=\"";
        // line 531
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/sidebareffect.js"), "html", null, true);
        echo "\"></script>

    <!-- Theme js -->
    <script src=\"";
        // line 534
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/script.js"), "html", null, true);
        echo "\"></script>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  831 => 534,  825 => 531,  819 => 528,  813 => 525,  807 => 522,  803 => 521,  796 => 517,  792 => 516,  788 => 515,  784 => 514,  780 => 513,  774 => 510,  770 => 509,  766 => 508,  760 => 505,  754 => 502,  748 => 499,  744 => 498,  738 => 495,  734 => 494,  728 => 491,  722 => 488,  719 => 487,  709 => 486,  698 => 443,  688 => 442,  676 => 60,  670 => 57,  664 => 54,  658 => 51,  652 => 48,  648 => 47,  642 => 44,  636 => 41,  630 => 38,  624 => 35,  618 => 32,  612 => 29,  609 => 28,  599 => 27,  580 => 18,  566 => 537,  564 => 486,  521 => 445,  519 => 442,  481 => 407,  441 => 370,  422 => 354,  401 => 336,  376 => 314,  358 => 299,  339 => 283,  314 => 261,  307 => 257,  275 => 228,  271 => 227,  256 => 215,  199 => 161,  184 => 149,  119 => 87,  110 => 81,  106 => 80,  86 => 62,  84 => 27,  72 => 18,  67 => 16,  63 => 15,  47 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\" dir=\"ltr\">


<!-- Mirrored from themes.pixelstrap.com/fastkart/back-end/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 10 Feb 2023 23:32:15 GMT -->
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta name=\"description\"
          content=\"Fastkart admin is super flexible, powerful, clean &amp; modern responsive bootstrap 5 admin template with unlimited possibilities.\">
    <meta name=\"keywords\"
          content=\"admin template, Fastkart admin template, dashboard template, flat admin template, responsive admin template, web app\">
    <meta name=\"author\" content=\"pixelstrap\">
    <link rel=\"icon\" href=\"{{asset('images/favicon.png')}}\" type=\"image/x-icon\">
    <link rel=\"shortcut icon\" href=\"{{asset('images/favicon.png')}}\" type=\"image/x-icon\">

    <title>{% block title %} Dashbord {% endblock %}</title>

    <!-- Google font-->
    <link
            href=\"https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap\"
            rel=\"stylesheet\">

    <!-- Linear Icon css -->

    {% block css %}

        <link rel=\"stylesheet\" href=\"{{asset('css/linearicon.css')}}\">

        <!-- fontawesome css -->
        <link rel=\"stylesheet\" href=\"{{asset('css/vendors/font-awesome.css')}}\">

        <!-- Themify icon css-->
        <link rel=\"stylesheet\" href=\"{{asset('css/vendors/themify.css')}}\">

        <!-- ratio css -->
        <link rel=\"stylesheet\" href=\"{{asset('css/ratio.css')}}\">

        <!-- remixicon css -->
        <link rel=\"stylesheet\" href=\"{{asset('css/remixicon.css')}}\">

        <!-- Feather icon css-->
        <link rel=\"stylesheet\" href=\"{{asset('css/vendors/feather-icon.css')}}\">

        <!-- Plugins css -->
        <link rel=\"stylesheet\" href=\"{{asset('css/vendors/scrollbar.css')}}\">
        <link rel=\"stylesheet\" href=\"{{asset('css/vendors/animate.css')}}\">

        <!-- Bootstrap css-->
        <link rel=\"stylesheet\" href=\"{{asset('css/vendors/bootstrap.css')}}\">

        <!-- vector map css -->
        <link rel=\"stylesheet\" href=\"{{asset('css/vector-map.css')}}\">

        <!-- Slick Slider Css -->
        <link rel=\"stylesheet\" href=\"{{asset('css/vendors/slick.css')}}\">

        <!-- App css -->
        <link rel=\"stylesheet\" href=\"{{asset('css/style.css')}}\">
    {% endblock %}
</head>

<body>

<!-- tap on top start -->
<div class=\"tap-top\">
    <span class=\"lnr lnr-chevron-up\"></span>
</div>
<!-- tap on tap end -->

<!-- page-wrapper Start-->
<div class=\"page-wrapper compact-wrapper\" id=\"pageWrapper\">
    <!-- Page Header Start-->
    <div class=\"page-header\">
        <div class=\"header-wrapper m-0\">
            <div class=\"header-logo-wrapper p-0\">
                <div class=\"logo-wrapper\">
                    <a href=\"index.html\">
                        <img class=\"img-fluid main-logo\" src=\"{{asset('images/logo/1.png')}}\" alt=\"logo\">
                        <img class=\"img-fluid white-logo\" src=\"{{asset('images/logo/1-white.png')}}\" alt=\"logo\">
                    </a>
                </div>
                <div class=\"toggle-sidebar\">
                    <i class=\"status_toggle middle sidebar-toggle\" data-feather=\"align-center\"></i>
                    <a href=\"index.html\">
                        <img src=\"{{asset('images/logo/1.png')}}\" class=\"img-fluid\" alt=\"\">
                    </a>
                </div>
            </div>

            <form class=\"form-inline search-full\" action=\"javascript:void(0)\" method=\"get\">
                <div class=\"form-group w-100\">
                    <div class=\"Typeahead Typeahead--twitterUsers\">
                        <div class=\"u-posRelative\">
                            <input class=\"demo-input Typeahead-input form-control-plaintext w-100\" type=\"text\"
                                   placeholder=\"Search Fastkart ..\" name=\"q\" title=\"\" autofocus>
                            <i class=\"close-search\" data-feather=\"x\"></i>
                            <div class=\"spinner-border Typeahead-spinner\" role=\"status\">
                                <span class=\"sr-only\">Loading...</span>
                            </div>
                        </div>
                        <div class=\"Typeahead-menu\"></div>
                    </div>
                </div>
            </form>
            <div class=\"nav-right col-6 pull-right right-header p-0\">
                <ul class=\"nav-menus\">
                    <li>
                            <span class=\"header-search\">
                                <i class=\"ri-search-line\"></i>
                            </span>
                    </li>
                    <li class=\"onhover-dropdown\">
                        <div class=\"notification-box\">
                            <i class=\"ri-notification-line\"></i>
                            <span class=\"badge rounded-pill badge-theme\">4</span>
                        </div>
                        <ul class=\"notification-dropdown onhover-show-div\">
                            <li>
                                <i class=\"ri-notification-line\"></i>
                                <h6 class=\"f-18 mb-0\">Notitications</h6>
                            </li>
                            <li>
                                <p>
                                    <i class=\"fa fa-circle me-2 font-primary\"></i>Delivery processing <span
                                            class=\"pull-right\">10 min.</span>
                                </p>
                            </li>
                            <li>
                                <p>
                                    <i class=\"fa fa-circle me-2 font-success\"></i>Order Complete<span
                                            class=\"pull-right\">1 hr</span>
                                </p>
                            </li>
                            <li>
                                <p>
                                    <i class=\"fa fa-circle me-2 font-info\"></i>Tickets Generated<span
                                            class=\"pull-right\">3 hr</span>
                                </p>
                            </li>
                            <li>
                                <p>
                                    <i class=\"fa fa-circle me-2 font-danger\"></i>Delivery Complete<span
                                            class=\"pull-right\">6 hr</span>
                                </p>
                            </li>
                            <li>
                                <a class=\"btn btn-primary\" href=\"{{asset('javascript:void(0)')}}\">Check all notification</a>
                            </li>
                        </ul>
                    </li>

                    <li>
                        <div class=\"mode\">
                            <i class=\"ri-moon-line\"></i>
                        </div>
                    </li>
                    <li class=\"profile-nav onhover-dropdown pe-0 me-0\">
                        <div class=\"media profile-media\">
                            <img class=\"user-profile rounded-circle\" src=\"{{asset('images/users/4.jpg')}}\" alt=\"\">
                            <div class=\"user-name-hide media-body\">
                                <span>Emay Walter</span>
                                <p class=\"mb-0 font-roboto\">Admin<i class=\"middle ri-arrow-down-s-line\"></i></p>
                            </div>
                        </div>
                        <ul class=\"profile-dropdown onhover-show-div\">
                            <li>
                                <a href=\"all-users.html\">
                                    <i data-feather=\"users\"></i>
                                    <span>Users</span>
                                </a>
                            </li>
                            <li>
                                <a href=\"order-list.html\">
                                    <i data-feather=\"archive\"></i>
                                    <span>Orders</span>
                                </a>
                            </li>
                            <li>
                                <a href=\"support-ticket.html\">
                                    <i data-feather=\"phone\"></i>
                                    <span>Spports Tickets</span>
                                </a>
                            </li>
                            <li>
                                <a href=\"profile-setting.html\">
                                    <i data-feather=\"settings\"></i>
                                    <span>Settings</span>
                                </a>
                            </li>
                            <li>
                                <a data-bs-toggle=\"modal\" data-bs-target=\"#staticBackdrop\"
                                   href=\"javascript:void(0)\">
                                    <i data-feather=\"log-out\"></i>
                                    <span>Log out</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Page Header Ends-->

    <!-- Page Body Start-->
    <div class=\"page-body-wrapper\">
        <!-- Page Sidebar Start-->
        <div class=\"sidebar-wrapper\">
            <div id=\"sidebarEffect\"></div>
            <div>
                <div class=\"logo-wrapper logo-wrapper-center\">
                    <a href=\"index.html\" data-bs-original-title=\"\" title=\"\">
                        <img class=\"img-fluid for-white\" src=\"{{asset('images/logo/1.png')}}\" alt=\"logo\">

                    </a>
                    <div class=\"back-btn\">
                        <i class=\"fa fa-angle-left\"></i>
                    </div>
                    <div class=\"toggle-sidebar\">
                        <i class=\"ri-apps-line status_toggle middle sidebar-toggle\"></i>
                    </div>
                </div>
                <div class=\"logo-icon-wrapper\">
                    <a href=\"index.html\">
                        <img class=\"img-fluid main-logo main-white\" src=\"{{asset('images/logo/logo.png')}}\" alt=\"logo\">
                        <img class=\"img-fluid main-logo main-dark\" src=\"{{asset('images/logo/logo-white.png')}}\"
                             alt=\"logo\">
                    </a>
                </div>
                <nav class=\"sidebar-main\">
                    <div class=\"left-arrow\" id=\"left-arrow\">
                        <i data-feather=\"arrow-left\"></i>
                    </div>

                    <div id=\"sidebar-menu\">
                        <ul class=\"sidebar-links\" id=\"simple-bar\">
                            <li class=\"back-btn\"></li>
                            <br>
                            <br>

                            <li class=\"sidebar-list\">
                                <a class=\"sidebar-link sidebar-title link-nav\" href=\"index.html\">
                                    <i class=\"ri-home-line\"></i>
                                    <span>Dashboard</span>
                                </a>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"linear-icon-link sidebar-link sidebar-title\" href=\"javascript:void(0)\">
                                    <i class=\"ri-store-3-line\"></i>
                                    <span>Contrat</span>
                                </a>
                                <ul class=\"sidebar-submenu\">
                                    <li>
                                        <a href=\"{{ path('contrat_read') }}\">Contrat</a>
                                    </li>

                                    <li>
                                        <a href=\"{{ path('contrat_add') }}\">Add New Contrat</a>
                                    </li>
                                </ul>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"linear-icon-link sidebar-link sidebar-title\" href=\"javascript:void(0)\">
                                    <i class=\"ri-list-check-2\"></i>
                                    <span>Category</span>
                                </a>
                                <ul class=\"sidebar-submenu\">
                                    <li>
                                        <a href=\"category.html\">Category List</a>
                                    </li>

                                    <li>
                                        <a href=\"add-new-category.html\">Add New Category</a>
                                    </li>
                                </ul>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"linear-icon-link sidebar-link sidebar-title\" href=\"{{asset('javascript:void(0)')}}\">
                                    <i class=\"ri-list-settings-line\"></i>
                                    <span>Attributes</span>
                                </a>
                                <ul class=\"sidebar-submenu\">
                                    <li>
                                        <a href=\"attributes.html\">Attributes</a>
                                    </li>

                                    <li>
                                        <a href=\"add-new-attributes.html\">Add Attributes</a>
                                    </li>
                                </ul>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"sidebar-link sidebar-title\" href=\"{{asset('javascript:void(0)')}}\">
                                    <i class=\"ri-user-3-line\"></i>
                                    <span>Users</span>
                                </a>
                                <ul class=\"sidebar-submenu\">
                                    <li>
                                        <a href=\"all-users.html\">All users</a>
                                    </li>
                                    <li>
                                        <a href=\"add-new-user.html\">Add new user</a>
                                    </li>
                                </ul>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"sidebar-link sidebar-title\" href=\"{{asset('javascript:void(0)')}}\">
                                    <i class=\"ri-user-3-line\"></i>
                                    <span>Roles</span>
                                </a>
                                <ul class=\"sidebar-submenu\">
                                    <li>
                                        <a href=\"role.html\">All roles</a>
                                    </li>
                                    <li>
                                        <a href=\"create-role.html\">Create Role</a>
                                    </li>
                                </ul>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"sidebar-link sidebar-title link-nav\" href=\"media.html\">
                                    <i class=\"ri-price-tag-3-line\"></i>
                                    <span>Media</span>
                                </a>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"sidebar-link sidebar-title\" href=\"{{asset('javascript:void(0)')}}\">
                                    <i class=\"ri-archive-line\"></i>
                                    <span>Orders</span>
                                </a>
                                <ul class=\"sidebar-submenu\">
                                    <li>
                                        <a href=\"order-list.html\">Order List</a>
                                    </li>
                                    <li>
                                        <a href=\"order-detail.html\">Order Detail</a>
                                    </li>
                                    <li>
                                        <a href=\"order-tracking.html\">Order Tracking</a>
                                    </li>
                                </ul>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"linear-icon-link sidebar-link sidebar-title\" href=\"{{asset('javascript:void(0)')}}\">
                                    <i class=\"ri-focus-3-line\"></i>
                                    <span>Localization</span>
                                </a>
                                <ul class=\"sidebar-submenu\">
                                    <li>
                                        <a href=\"translation.html\">Translation</a>
                                    </li>

                                    <li>
                                        <a href=\"currency-rates.html\">Currency Rates</a>
                                    </li>
                                </ul>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"linear-icon-link sidebar-link sidebar-title\" href=\"{{asset('javascript:void(0)')}}\">
                                    <i class=\"ri-price-tag-3-line\"></i>
                                    <span>Coupons</span>
                                </a>
                                <ul class=\"sidebar-submenu\">
                                    <li>
                                        <a href=\"coupon-list.html\">Coupon List</a>
                                    </li>

                                    <li>
                                        <a href=\"create-coupon.html\">Create Coupon</a>
                                    </li>
                                </ul>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"sidebar-link sidebar-title link-nav\" href=\"taxes.html\">
                                    <i class=\"ri-price-tag-3-line\"></i>
                                    <span>Tax</span>
                                </a>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"sidebar-link sidebar-title link-nav\" href=\"product-review.html\">
                                    <i class=\"ri-star-line\"></i>
                                    <span>Product Review</span>
                                </a>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"sidebar-link sidebar-title link-nav\" href=\"support-ticket.html\">
                                    <i class=\"ri-phone-line\"></i>
                                    <span>Support Ticket</span>
                                </a>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"linear-icon-link sidebar-link sidebar-title\" href=\"{{asset('javascript:void(0)')}}\">
                                    <i class=\"ri-settings-line\"></i>
                                    <span>Settings</span>
                                </a>
                                <ul class=\"sidebar-submenu\">
                                    <li>
                                        <a href=\"profile-setting.html\">Profile Setting</a>
                                    </li>
                                </ul>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"sidebar-link sidebar-title link-nav\" href=\"reports.html\">
                                    <i class=\"ri-file-chart-line\"></i>
                                    <span>Reports</span>
                                </a>
                            </li>

                            <li class=\"sidebar-list\">
                                <a class=\"sidebar-link sidebar-title link-nav\" href=\"list-page.html\">
                                    <i class=\"ri-list-check\"></i>
                                    <span>List Page</span>
                                </a>
                            </li>
                        </ul>
                    </div>

                    <div class=\"right-arrow\" id=\"right-arrow\">
                        <i data-feather=\"arrow-right\"></i>
                    </div>
                </nav>
            </div>
        </div>
        <!-- Page Sidebar Ends-->
        <div class=\"container mt-3\">
        {% block body %}

        {% endblock %}
        </div>

        <!-- footer start-->
        <div class=\"container-fluid\">
            <footer class=\"footer\">
                <div class=\"row\">
                    <div class=\"col-md-12 footer-copyright text-center\">
                        <p class=\"mb-0\">Copyright 2022 © Fastkart theme by cody</p>
                    </div>
                </div>
            </footer>
        </div>
        <!-- footer End-->
    </div>
    <!-- index body end -->

</div>
<!-- Page Body End -->
</div>
<!-- page-wrapper End-->

<!-- Modal Start -->
<div class=\"modal fade\" id=\"staticBackdrop\" data-bs-backdrop=\"static\" data-bs-keyboard=\"false\" tabindex=\"-1\"
     aria-labelledby=\"staticBackdropLabel\" aria-hidden=\"true\">
    <div class=\"modal-dialog  modal-dialog-centered\">
        <div class=\"modal-content\">
            <div class=\"modal-body\">
                <h5 class=\"modal-title\" id=\"staticBackdropLabel\">Logging Out</h5>
                <p>Are you sure you want to log out?</p>
                <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"modal\" aria-label=\"Close\"></button>
                <div class=\"button-box\">
                    <button type=\"button\" class=\"btn btn--no\" data-bs-dismiss=\"modal\">No</button>
                    <button type=\"button\" class=\"btn  btn--yes btn-primary\">Yes</button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal End -->

<!-- latest js -->
{% block js %}
    <!-- latest js -->
    <script src=\"{{ asset('js/jquery-3.6.0.min.js') }}\"></script>

    <!-- Bootstrap js -->
    <script src=\"{{ asset('js/bootstrap/bootstrap.bundle.min.js') }}\"></script>

    <!-- feather icon js -->
    <script src=\"{{ asset('js/icons/feather-icon/feather.min.js') }}\"></script>
    <script src=\"{{ asset('js/icons/feather-icon/feather-icon.js') }}\"></script>

    <!-- scrollbar simplebar js -->
    <script src=\"{{ asset('js/scrollbar/simplebar.js') }}\"></script>
    <script src=\"{{ asset('js/scrollbar/custom.js') }}\"></script>

    <!-- Sidebar jquery -->
    <script src=\"{{ asset('js/config.js') }}\"></script>

    <!-- tooltip init js -->
    <script src=\"{{ asset('js/tooltip-init.js') }}\"></script>

    <!-- Plugins JS -->
    <script src=\"{{ asset('js/sidebar-menu.js') }}\"></script>
    <script src=\"{{ asset('js/notify/bootstrap-notify.min.js') }}\"></script>
    <script src=\"{{ asset('js/notify/index.js') }}\"></script>

    <!-- Apexchar js -->
    <script src=\"{{ asset('js/chart/apex-chart/apex-chart1.js') }}\"></script>
    <script src=\"{{ asset('js/chart/apex-chart/moment.min.js') }}\"></script>
    <script src=\"{{ asset('js/chart/apex-chart/apex-chart.js') }}\"></script>
    <script src=\"{{ asset('js/chart/apex-chart/stock-prices.js') }}\"></script>
    <script src=\"{{ asset('js/chart/apex-chart/chart-custom1.js') }}\"></script>


    <!-- slick slider js -->
    <script src=\"{{ asset('js/slick.min.js') }}\"></script>
    <script src=\"{{ asset('js/custom-slick.js') }}\"></script>

    <!-- customizer js -->
    <script src=\"{{ asset('js/customizer.js') }}\"></script>

    <!-- ratio js -->
    <script src=\"{{ asset('js/ratio.js') }}\"></script>

    <!-- sidebar effect -->
    <script src=\"{{ asset('js/sidebareffect.js') }}\"></script>

    <!-- Theme js -->
    <script src=\"{{ asset('js/script.js') }}\"></script>

{% endblock %}
</body>


<!-- Mirrored from themes.pixelstrap.com/fastkart/back-end/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 10 Feb 2023 23:32:41 GMT -->
</html>", "base.html.twig", "C:\\xampp\\htdocs\\Contrat\\templates\\base.html.twig");
    }
}
