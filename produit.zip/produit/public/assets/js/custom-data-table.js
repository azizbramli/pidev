$(document).ready(function () {
    $('#table_id').DataTable({
        paging: false,
        ordering: false,
        info: false,
        responsive: true,
    });
});