<?php

namespace App\Controller;


use App\Entity\Produit;
use App\Form\ProduitType;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ProduitController extends AbstractController
{
    #[Route('/produit', name: 'app_produit')]
    public function index(): Response
    {
        return $this->render('/produit/index.html.twig', [
            'controller_name' => 'ProduitController',
        ]);
    }

    #[Route('/read', name: 'read_produit')]
    public function read(ManagerRegistry $doctrine): Response
    {
        $produit = $doctrine->getRepository(Produit::class)->findAll();
        return $this->render('produit/read.html.twig',
            ["produit" => $produit]);
    }

    #[Route('/add', name: 'add_produit')]
    public function  add(ManagerRegistry $doctrine, Request  $request) : Response
    { $produit = new Produit() ;
        $form = $this->createForm(ProduitType::class, $produit);
        $form->add('ajouter', SubmitType::class) ;
        $form->handleRequest($request);
        if ($form->isSubmitted())
        { $em = $doctrine->getManager();
            $em->persist($produit);
            $em->flush();
            return $this->redirectToRoute('read_produit');
        }
        return $this->renderForm("produit/add.html.twig",
            ["f"=>$form]) ;


    }
    #[Route('/update/{id}', name: 'update_produit')]
    public function  update(ManagerRegistry $doctrine,$id,  Request  $request) : Response
    { $classroom = $doctrine
        ->getRepository(Produit::class)
        ->find($id);
        $form = $this->createForm(ProduitType::class, $classroom);
        $form->add('update', SubmitType::class) ;
        $form->handleRequest($request);
        if ($form->isSubmitted())
        { $em = $doctrine->getManager();
            $em->flush();
            return $this->redirectToRoute('read_produit');
        }
        return $this->renderForm("produit/update.html.twig",
            ["f"=>$form]) ;


    }
    #[Route("/delete/{id}", name:'delete_produit')]
    public function delete($id, ManagerRegistry $doctrine)
    {$c = $doctrine
        ->getRepository(Produit::class)
        ->find($id);
        $em = $doctrine->getManager();
        $em->remove($c);
        $em->flush() ;
        return $this->redirectToRoute('read_produit');
    }
}
