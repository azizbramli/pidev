<?php

namespace App\Controller;

use App\Entity\User;
use App\Form\UserType;
use App\Repository\UserRepository;
use  Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Security;


class UserController extends AbstractController
{
    #[Route('/user', name: 'app_user')]
    public function index(): Response
    {
        return $this->render('basef.html.twig', [
            'controller_name' => 'UserController',
        ]);
    }
    #[Route('/read', name: 'user_read')]
    public function read(ManagerRegistry $doctrine): Response
    {
        $user = $doctrine->getRepository(User::class)->findAll();
        return $this->render('user/read.html.twig',
            ["user" => $user]);
    }

    #[Route('/edit', name: 'user_edit')]
    public function edit(Request $request, Security $security): Response
    {
        $user = $security->getUser();
    $form = $this->createForm(UserType::class, $user);
    
    $form->handleRequest($request);
    if ($form->isSubmitted() && $form->isValid()) {
        $entityManager = $this->getDoctrine()->getManager();
        $entityManager->flush();
        
        $this->addFlash('success', 'Profile updated successfully!');
        
        return $this->redirectToRoute('user_edit');
    }
    
    // Render the edit profile form
    return $this->render('user/edit.html.twig', [
        'form' => $form->createView(),
    ]);
    }
}
